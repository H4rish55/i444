#!/usr/bin/env node

import main from './main.js';

await main(process.argv.slice(2));
